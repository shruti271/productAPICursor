
var express  = require('express');
var mongoose = require('mongoose');
var app      = express();
var database = require('./config/database');
var bodyParser = require('body-parser');         // pull information from HTML POST (express4)
 
var port     = process.env.PORT || 8000;
app.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                     // parse application/json
app.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json


mongoose.connect(database.url);

var product = require('./models/products');
const ObjectId = mongoose.Types.ObjectId;
 
//get all product data from db
app.get('/api/products', function(req, res) {
	// use mongoose to get all todos in the database
	product.find(function(err, prd) {
		// if there is an error retrieving, send the error otherwise send data
		if (err)
			res.send(err)
		res.json(prd); // return all products in JSON format
	});
});

// get a product with ID of 1
app.get('/api/products/:product_id', function(req, res) {
    try{
	let validId = req.params.product_id;
    // console.log("-------------",id);
    // const validId = mongoose.Types.ObjectId(req.params.product_id);
    let objectId = ObjectId(validId);
	product.findById(validId, function(err, product) {
		if (err)
			res.send(err)
 
		res.json(product);
	});} catch (error) {
        console.error("Error converting to ObjectId:", error); // Debugging statement
        res.status(400).json({ message: 'Invalid product ID' });
    }
 
});


// create product and send back all products after creation
app.post('/api/products', function(req, res) {

    // create mongose method to create a new record into collection
    console.log(req.body);

	product.create({
		name : req.body.name,
		salary : req.body.salary,
		age : req.body.age
	}, function(err, product) {
		if (err)
			res.send(err);
 
		// get and return all the products after newly created employe record
		product.find(function(err, products) {
			if (err)
				res.send(err)
			res.json(products);
		});
	});
 
});


// create product and send back all products after creation
app.put('/api/products/:product_id', function(req, res) {
	// create mongose method to update an existing record into collection
    console.log(req.body);

	let id = req.params.product_id;
	var data = {
		name : req.body.name,
		salary : req.body.salary,
		age : req.body.age
	}

	// save the user
	product.findByIdAndUpdate(id, data, function(err, product) {
	if (err) throw err;

	res.send('Successfully! product updated - '+product.name);
	});
});

// delete a product by id
app.delete('/api/products/:product_id', function(req, res) {
	console.log(req.params.product_id);
	let id = req.params.product_id;
	product.remove({
		_id : id
	}, function(err) {
		if (err)
			res.send(err);
		else
			res.send('Successfully! product has been Deleted.');	
	});
});

app.listen(port);
console.log("App listening on port : " + port);
